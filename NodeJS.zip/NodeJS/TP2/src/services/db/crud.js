const { getCollection } = require('./connection');


async  function  findOne(collectionName, query, options = {}) {
    try {
        const  collection = getCollection(collectionName);
        const  result = await  collection.findOne(query, options);
        return  result;
    } catch (e) {
        console.log(`Erreur lors de l execution de la fonction findOne avec les parametres suivants: ${query}`);
        console.log(e);
        throw  e;
    }
}

async function find(collectionName, query, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.find(query, options).toArray();
        return result;
    } catch (e) {
        console.log(`Error executing find function with the following parameters: ${query}`);
        console.log(e);
        throw e;
    }
}

async function insertOne(collectionName, document, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.insertOne(document, options);
        return result;
    } catch (e) {
        console.log(`Error executing insertOne function with the following parameters: ${document}`);
        console.log(e);
        throw e;
    }
}

async function insertMany(collectionName, documents, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.insertMany(documents, options);
        return result;
    } catch (e) {
        console.log(`Error executing insertMany function with the following parameters: ${documents}`);
        console.log(e);
        throw e;
    }
}

async function updateOne(collectionName, filter, update, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.updateOne(filter, update, options);
        return result;
    } catch (e) {
        console.log(`Error executing updateOne function with the following parameters: ${filter}, ${update}`);
        console.log(e);
        throw e;
    }
}

async function updateMany(collectionName, filter, update, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.updateMany(filter, update, options);
        return result;
    } catch (e) {
        console.log(`Error executing updateMany function with the following parameters: ${filter}, ${update}`);
        console.log(e);
        throw e;
    }
}

async function replace(collectionName, filter, replacement, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.replaceOne(filter, replacement, options);
        return result;
    } catch (e) {
        console.log(`Error executing replace function with the following parameters: ${filter}, ${replacement}`);
        console.log(e);
        throw e;
    }
}

async function deleteOne(collectionName, filter, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.deleteOne(filter, options);
        return result;
    } catch (e) {
        console.log(`Error executing deleteOne function with the following parameters: ${filter}`);
        console.log(e);
        throw e;
    }
}

async function deleteMany(collectionName, filter, options = {}) {
    try {
        const collection = getCollection(collectionName);
        const result = await collection.deleteMany(filter, options);
        return result;
    } catch (e) {
        console.log(`Error executing deleteMany function with the following parameters: ${filter}`);
        console.log(e);
        throw e;
    }
}

module.exports = {
    findOne,
    find,
    insertOne,
    insertMany,
    updateOne,
    updateMany,
    replace,
    deleteOne,
    deleteMany,
};
