const express = require('express');
const router = express.Router();
const {createUser} = require('../controllers/items');


router.post('/createItems', createItems);

module.exports = router;