const express = require('express');
const router = express.Router();
const {createUser} = require('../controllers/users');

// const userSchema = require('../schemas/userSchema');
// const{validateSchemaMiddleware} = require('../services/validation');
// const {addUuid} = require('../services/uuid');
// router.get('/find', findUser);


router.post('/create', createUser);

module.exports = router;