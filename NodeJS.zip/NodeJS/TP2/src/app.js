const express = require('express')
const app = express()
const {createUser} = require('../src/controllers/users.js')
const {connectTodB} = require('./services/db/connection.js')
const {createItems} = require('../src/controllers/items.js')
const port = 3000

app.use((req, res, next) => {
  return next();
})

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.post('/users/create', createUser);
app.post('/items/createItems', createItems);

app.listen(port, () => {
  connectTodB(),
  console.log(`Example app listening on port ${port}`)
})