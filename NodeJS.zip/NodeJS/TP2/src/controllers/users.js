const {insertOne} = require("../services/db/crud.js")

async function createUser(req, res, next) {

    const value = req.body;
    
    const result = await insertOne('users', value);

    return res.status(201).send(result);

}

module.exports = {
    createUser
};