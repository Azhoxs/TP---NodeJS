const {insertOne} = require("../services/db/crud.js")

async function createItems(req, res, next) {

    const value = req.body;
    
    const result = await insertOne('items', value);

    return res.status(201).send(result);

}

module.exports = {
    createItems
};