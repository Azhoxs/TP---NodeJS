const userSchema = new mongoose.Schema({
    
    id: {
        type: Number,
        required: true,
        unique: true
    },
    nom: {
        type: String,
        required: true
    },
    prenom: {
        type: String,
        required: true,
    },
});
