const userSchema = new mongoose.Schema({
    
    id: {
        type: Number,
        required: true,
        unique: true
    },
    titre: {
        type: String,
        required: true,
        unique: true
    },
    date: {
        type: String,
        required: true,
    },
    duree: {
        type: Number,
        required: true,
        unique: true
    },
    genre: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true,
    },
    langue: {
        type: Number,
        required: true,
        unique: true
    },
    type: {
        type: String,
        required: true
    },
});