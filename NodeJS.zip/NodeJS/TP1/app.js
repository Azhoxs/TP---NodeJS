const express = require('express')
const app = express()
const port = 3000

app.use((req, res, next) => {
    const now = new Date();
    console.log(`[${now.toLocaleTimeString()}]: ${req.url}`);
    next(); 
});

app.get('/', (req, res) => {
  res.send('Hello World!')
});

app.get('/welcome', (req, res) => {
    res.send("Bienvenue sur le TP 1 du cours d'architecture logicielle");
});

app.get('/secret', (req, res) => {
    res.status(401).send("Vous ne possédez pas les droits pour accéder à ma page secrète");
});

app.get('/error', (req, res) => {
    res.status(500).json({ message: "Erreur interne du serveur" });
});

app.get('/img', (req, res) => {
    res.download("gasly.jpg");
});

app.get('/redirectMe', (req, res) => {
    res.redirect("https://extra.univ-littoral.fr/");
});

app.get('/users/:name', (req, res) => {
    const { name } = req.params;
    res.send(`Bienvenue sur la page de ${name}`);
  });

app.get('/somme', (req, res) => {
    const { a, b } = req.query;

    const sum = Number(a) + Number(b);
    res.send(`La somme de ${a} et ${b} est égale à ${sum}`);
});

app.use((req, res) => {
    res.status(404).send("Cette page n'existe pas!");
});

app.get('/metrics', (req, res) => {
    const uptimeInSeconds = process.uptime();
    
    const metrics = {
      status: "healthy",
      requestsCount: requestCounts,
      uptime: uptimeInSeconds
    };
  
    res.json(metrics);
  });

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
